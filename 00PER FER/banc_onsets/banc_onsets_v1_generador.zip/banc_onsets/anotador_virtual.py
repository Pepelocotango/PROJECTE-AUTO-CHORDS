# -*- coding: utf-8 -*-
"""Anotador virtual · Fase 0.A.

Implementa LITERALMENT el criteri numèric que ha d'aplicar l'anotador humà:

    primer sample on |x| supera  3 × RMS dels 20 ms previs,
    durant 3 samples consecutius.

Segon criteri declarat (alternatiu): |x| > 5 % del pic local, també amb 3
samples consecutius.

Treballa sobre el senyal ja renderitzat (amb soroll i filtres), tal com el
veuria una persona, i NO coneix la referència analítica ni el detector.

Ambigüitat de l'especificació que cal decidir abans de congelar: què són «els
20 ms previs»?

* ``base="fix"``      → la finestra de 20 ms que acaba on comença la zona de
  cerca (el que fa una persona: mira un tros tranquil abans de l'atac).
* ``base="lliscant"`` → els 20 ms immediatament anteriors a cada sample
  candidat. Amb pujades lentes el llindar puja amb el senyal i retarda la
  detecció.

Per defecte s'usa ``fix``; l'informe mostra totes dues.
"""
from __future__ import annotations

import numpy as np

PARAMS = {
    "finestra_base_s": 0.020,
    "factor_rms": 3.0,
    "consecutius": 3,
    "fraccio_pic_alt": 0.05,
    "cerca_abans_s": 0.050,
    "cerca_despres_s": 0.080,
}


def parametres():
    return dict(PARAMS)


def a_mono_abs(x):
    """Valor absolut d'un senyal 1-D o (n, canals): màxim entre canals."""
    x = np.abs(np.asarray(x, dtype=np.float64))
    return x if x.ndim == 1 else x.max(axis=1)


def anota(x, sr, t_aprox, criteri="rms", base="fix"):
    """Retorna el temps (s) de l'atac anotat, o None si no en troba cap.

    ``t_aprox`` és el punt aproximat on l'anotador «ha fet clic»; la cerca
    s'estén de ``t_aprox - 50 ms`` a ``t_aprox + 80 ms``.
    """
    a = a_mono_abs(x)
    p = PARAMS
    w = max(1, int(round(p["finestra_base_s"] * sr)))
    k = int(p["consecutius"])
    centre = int(round(float(t_aprox) * sr))
    lo = max(0, centre - int(round(p["cerca_abans_s"] * sr)))
    hi = min(a.size, centre + int(round(p["cerca_despres_s"] * sr)))
    if hi - lo <= k:
        return None

    if criteri == "pic":
        llindar = p["fraccio_pic_alt"] * float(a[lo:hi].max())
        llindar = np.full(hi - lo - k + 1, llindar)
    elif criteri == "rms":
        quad = np.concatenate([[0.0], np.cumsum(a * a)])

        def rms(i0, i1):
            i0 = max(0, i0)
            n = max(1, i1 - i0)
            return np.sqrt(max(quad[i1] - quad[i0], 0.0) / n)

        if base == "fix":
            r = rms(lo - w, lo) if lo >= 1 else rms(0, min(w, a.size))
            llindar = np.full(hi - lo - k + 1, p["factor_rms"] * r)
        elif base == "lliscant":
            idx = np.arange(lo, hi - k + 1)
            ini = np.maximum(idx - w, 0)
            n = np.maximum(idx - ini, 1)
            r = np.sqrt(np.maximum(quad[idx] - quad[ini], 0.0) / n)
            llindar = p["factor_rms"] * r
        else:
            raise ValueError(f"base desconeguda: {base!r}")
    else:
        raise ValueError(f"criteri desconegut: {criteri!r}")

    ok = np.ones(hi - lo - k + 1, dtype=bool)
    for j in range(k):
        ok &= a[lo + j:hi - k + 1 + j] > llindar
    if not ok.any():
        return None
    return (lo + int(np.argmax(ok))) / float(sr)
